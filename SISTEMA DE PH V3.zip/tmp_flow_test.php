<?php
require 'conexao.php';
$base = 'http://localhost/Sistema-Registrador-de-pH---IFSEMG';
$cookieFile = __DIR__ . '/tmp_cookies.txt';
@unlink($cookieFile);

function httpRequest($url, $method = 'GET', $data = [], $cookieFile = null) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data, '', '&'));
    }
    $response = curl_exec($ch);
    if ($response === false) {
        throw new RuntimeException(curl_error($ch));
    }
    curl_close($ch);
    return $response;
}

httpRequest($base . '/login.php', 'POST', ['email' => 'admin@gmail.com', 'senha' => '123456'], $cookieFile);

$createPage = httpRequest($base . '/medicoes_cadastrar.php', 'GET', [], $cookieFile);
preg_match('/name="csrf_token" value="([^"]+)"/', $createPage, $createMatches);
$createToken = $createMatches[1] ?? '';
$now = date('Y-m-d\TH:i');
$createResult = httpRequest($base . '/medicoes_cadastrar.php', 'POST', [
    'csrf_token' => $createToken,
    'valor_ph' => '7.10',
    'temperatura' => '25.5',
    'amostra' => 'Teste automático fluxo',
    'observacao' => 'Validação',
    'data_medicao' => $now
], $cookieFile);

$res = mysqli_query($conexao, "SELECT id FROM medicoes_ph WHERE amostra = 'Teste automático fluxo' ORDER BY id DESC LIMIT 1");
$row = mysqli_fetch_assoc($res);
$id = (int)($row['id'] ?? 0);
if (!$id) {
    echo "NO_MEASUREMENT\n";
    exit(1);
}

$editPage = httpRequest($base . '/medicoes_editar.php?id=' . $id, 'GET', [], $cookieFile);
preg_match('/name="csrf_token" value="([^"]+)"/', $editPage, $editMatches);
$editToken = $editMatches[1] ?? '';
$editResult = httpRequest($base . '/medicoes_editar.php?id=' . $id, 'POST', [
    'csrf_token' => $editToken,
    'valor_ph' => '7.20',
    'temperatura' => '26.0',
    'amostra' => 'Teste automático fluxo editado',
    'observacao' => 'Editado por teste',
    'data_medicao' => $now
], $cookieFile);

$listPage = httpRequest($base . '/medicoes_listar.php', 'GET', [], $cookieFile);
preg_match('/name="csrf_token" value="([^"]+)"/', $listPage, $listMatches);
$deleteToken = $listMatches[1] ?? '';
$deleteResult = httpRequest($base . '/medicoes_excluir.php', 'POST', [
    'csrf_token' => $deleteToken,
    'id' => $id
], $cookieFile);

$listAfterDelete = httpRequest($base . '/medicoes_listar.php', 'GET', [], $cookieFile);
$edited = strpos($listAfterDelete, 'Teste automático fluxo editado') !== false;
$deleted = strpos($listAfterDelete, 'Teste automático fluxo editado') === false;

echo "ID=$id\n";
echo "CREATE_STATUS=" . (strpos($createResult, 'Location: medicoes_listar.php') !== false ? 'ok' : 'fail') . "\n";
echo "EDIT_STATUS=" . (strpos($editResult, 'Location: medicoes_listar.php') !== false ? 'ok' : 'fail') . "\n";
echo "EDITED_IN_LIST=" . ($edited ? 'yes' : 'no') . "\n";
echo "DELETED=" . ($deleted ? 'yes' : 'no') . "\n";
