<?php
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'phmetro';

date_default_timezone_set('America/Sao_Paulo');

$conexao = mysqli_connect($host, $usuario, $senha, $banco);

if (!$conexao) {
    die('Erro ao conectar ao banco de dados: ' . mysqli_connect_error());
}

mysqli_set_charset($conexao, 'utf8mb4');
mysqli_query($conexao, "SET time_zone = '-03:00'");
