<?php
require 'conexao.php';
require 'auth.php';

exigir_login();

$valor_ph_min = trim($_GET['valor_ph_min'] ?? '');
$valor_ph_max = trim($_GET['valor_ph_max'] ?? '');
$temperatura_min = trim($_GET['temperatura_min'] ?? '');
$temperatura_max = trim($_GET['temperatura_max'] ?? '');
$nome_liquido = trim($_GET['nome_liquido'] ?? '');
$observacao = trim($_GET['observacao'] ?? '');
$sem_observacao = isset($_GET['sem_observacao']) && $_GET['sem_observacao'] == '1';
$data_medicao_inicio = trim($_GET['data_medicao_inicio'] ?? '');
$data_medicao_fim = trim($_GET['data_medicao_fim'] ?? '');

$usuario_id = $_SESSION['usuario_id'];

function normalize_search_string(string $value): string {
    $value = mb_strtolower($value, 'UTF-8');
    return strtr($value, [
        'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a', 'ä' => 'a',
        'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
        'ó' => 'o', 'ò' => 'o', 'õ' => 'o', 'ô' => 'o', 'ö' => 'o',
        'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
        'ç' => 'c',
    ]);
}

$sql = '
SELECT 
    id,
    valor_ph,
    temperatura,
    nome_liquido,
    observacao,
    data_medicao
FROM medicoes_ph
WHERE usuario_id = ?
';

$params = [$usuario_id];
$types = 'i';

$nome_liquido_search_expr = "LOWER(nome_liquido)";
foreach ([
    'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a', 'ä' => 'a',
    'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
    'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
    'ó' => 'o', 'ò' => 'o', 'õ' => 'o', 'ô' => 'o', 'ö' => 'o',
    'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
    'ç' => 'c',
] as $from => $to) {
    $nome_liquido_search_expr = "REPLACE($nome_liquido_search_expr, '$from', '$to')";
}

// Filtro de pH mínimo
if ($valor_ph_min !== '' && is_numeric($valor_ph_min)) {
    $sql .= " AND valor_ph >= ?";
    $params[] = (float)$valor_ph_min;
    $types .= 'd';
}

// Filtro de pH máximo
if ($valor_ph_max !== '' && is_numeric($valor_ph_max)) {
    $sql .= " AND valor_ph <= ?";
    $params[] = (float)$valor_ph_max;
    $types .= 'd';
}

// Filtro de temperatura mínima
if ($temperatura_min !== '' && is_numeric($temperatura_min)) {
    $sql .= " AND COALESCE(temperatura, 25) >= ?";
    $params[] = (float)$temperatura_min;
    $types .= 'd';
}
 
// Filtro de temperatura máxima
if ($temperatura_max !== '' && is_numeric($temperatura_max)) {
    $sql .= " AND COALESCE(temperatura, 25) <= ?";
    $params[] = (float)$temperatura_max;
    $types .= 'd';
}

if ($nome_liquido !== '') {
    $sql .= " AND $nome_liquido_search_expr LIKE ?";
    $params[] = normalize_search_string($nome_liquido) . '%';
    $types .= 's';
}

if ($sem_observacao) {
    $sql .= " AND TRIM(COALESCE(observacao, '')) = ''";
} elseif ($observacao !== '') {
    $sql .= " AND observacao LIKE ?";
    $params[] = "%$observacao%";
    $types .= 's';
}

if ($data_medicao_inicio !== '' && strtotime($data_medicao_inicio) !== false) {
    $sql .= " AND DATE(data_medicao) >= ?";
    $params[] = date('Y-m-d', strtotime($data_medicao_inicio));
    $types .= 's';
}

if ($data_medicao_fim !== '' && strtotime($data_medicao_fim) !== false) {
    $sql .= " AND DATE(data_medicao) <= ?";
    $params[] = date('Y-m-d', strtotime($data_medicao_fim));
    $types .= 's';
}

$sql .= ' ORDER BY id DESC';

$stmt = mysqli_prepare($conexao, $sql);

mysqli_stmt_bind_param($stmt, $types, ...$params);

mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Lista de medições</title>

    <link rel="stylesheet" href="estilo.css">

</head>

<body>

<div class="container">

<div class="logo-area logo-list">
    <img src="imagens/logo-sistema.png" alt="Sistema Registrador de pH" class="logo-system">
</div>

    <div class="topbar">

        <div>

            <h2>Medições de pH</h2>

            <div class="small">
                Registros vinculados ao seu usuário.
            </div>

        </div>

        <div class="topbar-actions">
            <a class="btn btn-danger" href="logout.php">
                Sair
            </a>
        </div>

    </div>

    <div class="page-grid">

        <main class="results-panel">

            <div class="search-section">
                <label for="liquido-search">Pesquisar nome do líquido</label>
                <input
                    id="liquido-search"
                    type="search"
                    placeholder="Digite o nome do líquido"
                    value="<?php echo htmlspecialchars($nome_liquido); ?>"
                >
            </div>

            <div class="table-wrap">
 
                <table>

                    <thead>

                    <tr>

                        <th>Valor pH</th>

                        <th>Temperatura</th>

                        <th>Nome do líquido</th>

                        <th>Observação</th>

                        <th>Data</th>

                        <th>Ações</th>

                    </tr>

                    </thead>

                    <tbody>

                    <?php if (mysqli_num_rows($resultado) === 0): ?>

                        <tr>

                            <td colspan="6">
                                Nenhuma medição encontrada.
                            </td>

                        </tr>

                    <?php else: ?>

                        <?php while ($linha = mysqli_fetch_assoc($resultado)): ?>

                            <tr>

                                <td>

                                    <?php
                                    echo number_format(
                                        (float)$linha['valor_ph'], 
                                        2,
                                        ',',
                                        '.'
                                    );
                                    ?>

                                </td>

                                <td>
 
                                    <?php
                                    if ($linha['temperatura'] === null || $linha['temperatura'] === '') {
                                        echo '';
                                    } else {
                                        echo number_format(
                                            (float)$linha['temperatura'], 
                                            2,
                                            ',',
                                            '.'
                                        ) . ' °C';
                                    }
                                    ?>
 
                                </td>

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $linha['nome_liquido']
                                    );
                                    ?>

                                </td>

                                <td>

                                    <?php
                                    $observacao_exibida = trim((string)($linha['observacao'] ?? ''));
                                    echo htmlspecialchars(
                                        $observacao_exibida !== '' ? $observacao_exibida : 'Nenhuma observação escrita'
                                    );
                                    ?>

                                </td>

                                <td>

                                    <?php

                                    $data = new DateTime(
                                        $linha['data_medicao']
                                    );

                                    echo $data->format(
                                        'd/m/Y \à\s H:i'
                                    );

                                    ?>

                                </td>

                                <td class="actions">

                                    <a href="medicoes_editar.php?id=<?php echo $linha['id']; ?>">
                                        Editar
                                    </a>

                                    <a href="medicoes_excluir.php?id=<?php echo $linha['id']; ?>"
                                       onclick="return confirm('Excluir esta medição?')">

                                        Excluir

                                    </a>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </main>

        <aside class="sidebar">

            <div class="sidebar-actions">
                <a class="btn btn-highlight" href="medicoes_cadastrar.php">Nova medição</a>
            </div>

            <section class="filter-panel">

                <h3>Filtros</h3>

                <form method="GET">
                    <input
                        type="hidden"
                        name="nome_liquido"
                        value="<?php echo htmlspecialchars($nome_liquido); ?>"
                    >

                    <div class="filters-grid">

                        <div class="filter-group">
                            <label>Valor pH</label>
                            <div class="split-inputs">
                                <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="14"
                                    name="valor_ph_min"
                                    placeholder="Mínimo"
                                    value="<?php echo htmlspecialchars($valor_ph_min); ?>"
                                >
                                <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="14"
                                    name="valor_ph_max"
                                    placeholder="Máximo"
                                    value="<?php echo htmlspecialchars($valor_ph_max); ?>"
                                >
                            </div>
                        </div>

                        <div class="filter-group">
                            <label>Temperatura (°C)</label>
                            <div class="split-inputs">
                                <input
                                    type="number"
                                    step="0.1"
                                    name="temperatura_min"
                                    placeholder="Mínimo"
                                    value="<?php echo htmlspecialchars($temperatura_min); ?>"
                                >
                                <input
                                    type="number"
                                    step="0.1"
                                    name="temperatura_max"
                                    placeholder="Máximo"
                                    value="<?php echo htmlspecialchars($temperatura_max); ?>"
                                >
                            </div>
                        </div>

                        <div class="filter-group full-width">
                            <label>Observação</label>
                            <input
                                id="observacao-filter"
                                type="text"
                                name="observacao"
                                placeholder="Digite uma observação"
                                value="<?php echo htmlspecialchars($observacao); ?>"
                                <?php echo $sem_observacao ? 'disabled' : ''; ?>
                            >
                            <label style="display: inline-flex; align-items: center; gap: 2px; margin-top: 2px; font-weight: 500; font-size: 12px; line-height: 1.1;">
                                <input
                                    type="checkbox"
                                    name="sem_observacao"
                                    value="1"
                                    style="margin: 0; width: 12px; height: 12px;"
                                    <?php echo $sem_observacao ? 'checked' : ''; ?>
                                >
                                Buscar itens sem observação
                            </label>
                        </div>

                        <div class="filter-group">
                            <label>Data de medição</label>
                            <div class="date-range">
                                <span>de</span>
                                <input
                                    type="date"
                                    name="data_medicao_inicio"
                                    value="<?php echo htmlspecialchars($data_medicao_inicio); ?>"
                                >
                                <span>até</span>
                                <input
                                    type="date"
                                    name="data_medicao_fim"
                                    value="<?php echo htmlspecialchars($data_medicao_fim); ?>"
                                >
                            </div>
                        </div>

                    </div>

                    <div class="buttons">

                        <button class="btn" type="submit">
                            Filtrar
                        </button>

                        <a class="btn-secondary"
                           href="medicoes_listar.php">
                            Limpar filtros
                        </a>

                    </div>

                </form>

        </section>

        </aside>

    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const topSearch = document.getElementById('liquido-search');
    const filterForm = document.querySelector('.filter-panel form');
    const nomeInput = filterForm ? filterForm.querySelector('[name="nome_liquido"]') : null;
    const resultsBody = document.querySelector('.table-wrap table tbody');
    const observacaoInput = filterForm ? filterForm.querySelector('#observacao-filter') : null;
    const semObservacaoCheckbox = filterForm ? filterForm.querySelector('[name="sem_observacao"]') : null;
    let debounceTimer;

    if (!topSearch || !filterForm || !nomeInput || !resultsBody) {
        return;
    }

    const syncObservacaoFilter = () => {
        if (!observacaoInput || !semObservacaoCheckbox) {
            return;
        }

        observacaoInput.disabled = semObservacaoCheckbox.checked;
    };

    syncObservacaoFilter();

    if (semObservacaoCheckbox) {
        semObservacaoCheckbox.addEventListener('change', syncObservacaoFilter);
    }

    const updateResults = async () => {
        const params = new URLSearchParams(new FormData(filterForm));
        params.set('nome_liquido', topSearch.value);

        try {
            const response = await fetch(window.location.pathname + '?' + params.toString(), {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                cache: 'no-store'
            });

            if (!response.ok) {
                throw new Error('Falha ao buscar resultados.');
            }

            const text = await response.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(text, 'text/html');
            const newBody = doc.querySelector('.table-wrap table tbody');
            const newSearchValue = doc.querySelector('#liquido-search');
            const currentHidden = filterForm.querySelector('[name="nome_liquido"]');

            if (newBody) {
                resultsBody.innerHTML = newBody.innerHTML;
            }

            if (currentHidden) {
                currentHidden.value = topSearch.value;
            }
        } catch (error) {
            console.error(error);
            filterForm.submit();
        }
    };

    topSearch.addEventListener('input', function () {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(updateResults, 350);
    });
});
</script>
</body>
</html>