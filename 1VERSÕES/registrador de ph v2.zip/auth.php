<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function gerar_csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function validar_csrf_token(?string $token): bool {
    return isset($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}

function set_flash(string $tipo, string $mensagem): void {
    $_SESSION['flash_' . $tipo] = $mensagem;
}

function get_flash(string $tipo): string {
    $mensagem = $_SESSION['flash_' . $tipo] ?? '';
    unset($_SESSION['flash_' . $tipo]);
    return $mensagem;
}

function exigir_login(): void {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: login.php');
        exit;
    }

    $aprovado = isset($_SESSION['usuario_aprovado']) ? (int) $_SESSION['usuario_aprovado'] : 0;
    $ativo = isset($_SESSION['usuario_ativo']) ? (int) $_SESSION['usuario_ativo'] : 0;

    if ($aprovado !== 1 || $ativo !== 1) {
        header('Location: login.php');
        exit;
    }
}

function exigir_admin(): void {
    exigir_login();

    if (!isset($_SESSION['usuario_role']) || $_SESSION['usuario_role'] !== 'admin') {
        header('Location: index.php');
        exit;
    }
}

function is_admin(): bool {
    return !empty($_SESSION['usuario_role']) && $_SESSION['usuario_role'] === 'admin';
}
?>

